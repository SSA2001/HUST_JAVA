package hust.cs.javacourse.search.parse.impl;

import hust.cs.javacourse.search.index.AbstractTermTuple;
import hust.cs.javacourse.search.index.impl.Term;
import hust.cs.javacourse.search.index.impl.TermTuple;
import hust.cs.javacourse.search.parse.AbstractTermTupleScanner;
import hust.cs.javacourse.search.util.Config;
import hust.cs.javacourse.search.util.StringSplitter;

import java.io.BufferedReader;
import java.io.IOException;
import java.util.LinkedList;


/**
 * AbstractTermTupleScanner的具体实现类
 * @author ShiShenao
 * @date 2021/4/16
 **/
public class TermTupleScanner extends AbstractTermTupleScanner {
    public TermTupleScanner(BufferedReader input) {
        super(input);
    }

    /**
     * 位置
     */
    private int pos = 0;

    /**
     * 用于缓存每一行多余的数据
     */
    LinkedList<AbstractTermTuple> inputBuffer = new LinkedList<AbstractTermTuple>();

    /**
     * 获得下一个三元组
     * @return 下一个三元组；如果到了流的末尾，返回null
     * @date 2021/4/16 22:12
     */
    @Override
    public AbstractTermTuple next() {
        try {
            if (inputBuffer.isEmpty()) {
                String string = input.readLine();
                if (string == null) {// 如果读完了，直接返回null
                    return null;
                }
                while (string.trim().length() == 0) {
                    string = input.readLine();// 当遇到空行的时候，就一直读，直到遇到非空行或者文件末尾
                    if (string == null) {
                        return null;
                    }
                }
                StringSplitter splitter = new StringSplitter();
                splitter.setSplitRegex(Config.STRING_SPLITTER_REGEX);//进行切分
                for (String word : splitter.splitByRegex(string)) {
                    TermTuple termTuple = new TermTuple();
                    termTuple.curPos = pos;
                    if (Config.IGNORE_CASE) {// 是否忽略大小写
                        termTuple.term = new Term(word.toLowerCase());
                    } else {
                        termTuple.term = new Term(word);
                    }
                    inputBuffer.add(termTuple);
                    pos++;
                }
            }
        }
        catch (IOException e) {
                e.printStackTrace();
            }
        return inputBuffer.poll();
    }
}
