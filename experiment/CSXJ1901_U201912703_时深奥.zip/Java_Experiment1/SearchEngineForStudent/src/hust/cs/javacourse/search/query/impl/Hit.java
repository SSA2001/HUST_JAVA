package hust.cs.javacourse.search.query.impl;

import hust.cs.javacourse.search.index.AbstractPosting;
import hust.cs.javacourse.search.index.AbstractTerm;
import hust.cs.javacourse.search.query.AbstractHit;

import java.util.Map;

/**
 * AbstractHit的具体实现子类
 * @author ShiShenao
 * @date 2021/4/16
 **/
public class Hit extends AbstractHit {
    /**
     * 缺省构造函数
     * @date 2021/4/16 20:39
     */
    public Hit(){}

    /**
     * 构造函数
     * @param docId:文档id
     * @param docPath:文档绝对路径
     * @date 2021/4/16 20:39
     */
    public Hit(int docId, String docPath){
        super(docId, docPath);
    }

    /**
     * 构造函数
     * @param docId:文档id
     * @param docPath:文档绝对路径
     * @param termPostingMapping:命中的三元组列表
     * @date 2021/4/16 20:41
     */
    public Hit(int docId, String docPath, Map<AbstractTerm, AbstractPosting> termPostingMapping){
        super(docId, docPath, termPostingMapping);
    }

    /**
     * 获取文档id
     * @return 文档id
     * @date 2021/4/16 20:38
     */
    @Override
    public int getDocId() {
        return this.docId;
    }

    /**
     * 获取文档绝对路径
     * @return 文档绝对路径
     * @date 2021/4/16 20:42
     */
    @Override
    public String getDocPath() {
        return this.docPath;
    }

    /**
     * 获得文档内容
     * @return 文档内容
     * @date 2021/4/16 20:43
     */
    @Override
    public String getContent() {
        return this.content;
    }

    /**
     * 设置文档内容
     * @param content:文档内容
     * @date 2021/4/16 20:43
     */
    @Override
    public void setContent(String content) {
        this.content = content;
    }

    /**
     * 获得文档得分
     * @return 文档得分
     * @date 2021/4/16 20:43
     */
    @Override
    public double getScore() {
        return this.score;
    }

    /**
     * 设置文档得分
     * @param score:文档得分
     * @date 2021/4/16 20:45
     */
    @Override
    public void setScore(double score) {
        this.score = score;
    }

    /**
     * 获得命中的单词和对应的Posting键值对
     * @return 命中的单词和对应的Posting键值对
     * @date 2021/4/16 20:47
     */
    @Override
    public Map<AbstractTerm, AbstractPosting> getTermPostingMapping() {
        return this.termPostingMapping;
    }

    /**
     * 获得命中结果的字符串表示, 用于显示搜索结果.
     * @return 命中结果的字符串表示
     * @date 2021/4/16 20:53
     */
    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("\n--------------------------------------");
        builder.append("\n\ndocId: ").append(docId).append("\n\ndocPath: ").append(docPath)
                .append("\n\ncontent: ").append(content).append("\n\nscore: ").append(score).append("\n\n");
        for (Map.Entry<AbstractTerm, AbstractPosting> entry: termPostingMapping.entrySet()) {
            builder.append(entry.getKey().getContent()).append("\t---->\t").append(entry.getValue()).append("\n");
        }
        return builder.toString();
    }

    /**
     * 比较二个命中结果的大小，根据score比较
     * @param o:要比较的名字结果
     * @return 二个命中结果得分的差值
     * @date 2021/4/16 20:49
     */
    @Override
    public int compareTo(AbstractHit o) {
        return (int)(getScore() - o.getScore());
    }
}
