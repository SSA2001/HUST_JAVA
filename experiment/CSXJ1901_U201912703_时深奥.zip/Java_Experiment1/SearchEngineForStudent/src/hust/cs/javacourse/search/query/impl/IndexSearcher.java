package hust.cs.javacourse.search.query.impl;

import hust.cs.javacourse.search.index.AbstractPosting;
import hust.cs.javacourse.search.index.AbstractPostingList;
import hust.cs.javacourse.search.index.AbstractTerm;
import hust.cs.javacourse.search.index.impl.Index;
import hust.cs.javacourse.search.index.impl.Posting;
import hust.cs.javacourse.search.index.impl.Term;
import hust.cs.javacourse.search.query.AbstractHit;
import hust.cs.javacourse.search.query.AbstractIndexSearcher;
import hust.cs.javacourse.search.query.Sort;


import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 搜索功能的实现
 * @author ShiShenao
 * @date 2021/4/16
 **/
public class IndexSearcher extends AbstractIndexSearcher {

    private AbstractTerm queryTerm1;
    private AbstractTerm queryTerm2;
    private Sort sorter;

    /**
     * 从指定索引文件打开索引,加载到index对象里.一定要先打开索引,才能执行search方法
     * @param indexFile:指定索引文件
     * @date 2021/4/17 17:01
     */
    @Override
    public void open(String indexFile) {
        this.index.load(new File(indexFile));
        this.index.optimize();//进行排序
    }


   /**
     * 根据单个检索词进行搜索
     * @param queryTerm:检索词
     * @param sorter:排序器
     * @return 命中结果数组
     * @date 2021/4/22 19:54
     **/
    @Override
    public AbstractHit[] search(AbstractTerm queryTerm, Sort sorter) {
        AbstractPostingList postList = index.search(queryTerm);
        if (postList == null)
            return null;
        List<AbstractHit> hits = new ArrayList<>();
        for (int i = 0; i < postList.size(); i++) {
            AbstractPosting post = postList.get(i);
            String path = index.getDocName(post.getDocId());
            Map<AbstractTerm, AbstractPosting> map = new HashMap<>();
            map.put(queryTerm, post);
            AbstractHit hit = new Hit(post.getDocId(), path, map);
            hit.setScore(sorter.score(hit));//设置分数
            hits.add(hit);
        }
        sorter.sort(hits);//对hits进行排序
        return hits.toArray(new AbstractHit[0]);
    }

    /**
     * 根据二个检索词及其关系进行搜索
     * @param queryTerm1:第1个检索词
     * @param queryTerm2:第2个检索词
     * @param sorter:排序器
     * @param combine:多个检索词的逻辑组合方式
     * @return 命中结果数组
     * @date 2021/4/22 18:49
     */
    @Override
    public AbstractHit[] search(AbstractTerm queryTerm1, AbstractTerm queryTerm2, Sort sorter, LogicalCombination combine) {
        AbstractPostingList indexSearchResult1 = index.search(queryTerm1);
        AbstractPostingList indexSearchResult2 = index.search(queryTerm2);
        // 如果两个都没找到直接就是空的数组
        if (indexSearchResult1 == null && indexSearchResult2 == null) {
            return new Hit[0];
        }
        List<AbstractHit> result = new ArrayList<>();
        if (combine == LogicalCombination.AND) {
            // 如果有一个词语根本就不存在，那就直接返回空的数组
            if (indexSearchResult1 == null || indexSearchResult2 == null) {
                return new Hit[0];
            }
            // 求交集
            for (int i = 0; i < indexSearchResult1.size(); i++) {
                // 获取docId
                int docId = indexSearchResult1.get(i).getDocId();
                int sub_index = indexSearchResult2.indexOf(docId);
                if (sub_index != -1) {//如果都存在该d文件
                    AbstractHit hit = new Hit(docId, index.getDocName(docId));
                    hit.getTermPostingMapping().put(queryTerm1, indexSearchResult1.get(i));
                    hit.getTermPostingMapping().put(queryTerm2, indexSearchResult2.get(sub_index));
                    hit.setScore(sorter.score(hit));//设置分数
                    result.add(hit);
                }
            }
        } else if (combine == LogicalCombination.OR) {
            // 如果有一个词语不存在直接退化为对另外一个词语的搜索
            if (indexSearchResult1 == null) {
                return search(queryTerm2, sorter);
            }
            if (indexSearchResult2 == null) {
                return search(queryTerm1, sorter);
            }

            for (int i = 0; i < indexSearchResult1.size(); i++) {
                // 首先添加
                int docId = indexSearchResult1.get(i).getDocId();
                int sub_index = indexSearchResult2.indexOf(docId);
                if (sub_index == -1) {
                    // 如果在另外一个词语中没有,那就正常添加
                    AbstractHit hit = new Hit(docId, index.getDocName(docId));
                    hit.getTermPostingMapping().put(queryTerm1, indexSearchResult1.get(i));
                    hit.setScore(sorter.score(hit));
                    result.add(hit);
                } else {
                    // 如果在另外一个中有, 那就要做一些修改
                    AbstractHit hit = new Hit(docId, index.getDocName(docId));
                    hit.getTermPostingMapping().put(queryTerm1, indexSearchResult1.get(i));
                    hit.getTermPostingMapping().put(queryTerm2, indexSearchResult2.get(sub_index));//把2中的也放进去
                    hit.setScore(sorter.score(hit));
                    result.add(hit);
                }
            }
            for (int i = 0; i < indexSearchResult2.size(); i++) {
                int docId = indexSearchResult2.get(i).getDocId();
                int sub_index = indexSearchResult1.indexOf(docId);
                if (sub_index == -1) {
                    // 只有当1中不存在的时候才添加
                    AbstractHit hit = new Hit(docId, index.getDocName(docId));
                    hit.getTermPostingMapping().put(queryTerm2, indexSearchResult2.get(i));
                    hit.setScore(sorter.score(hit));
                    result.add(hit);
                }
            }
        }

        sorter.sort(result);//排序
        AbstractHit[] returnResult = new AbstractHit[result.size()];
        return result.toArray(returnResult);
    }

    /**
     * 根据二个连续检索词进行搜索
     * @param queryTerm1:第1个检索词
     * @param queryTerm2:第2个检索词
     * @param sorter:排序器
     * @return 命中结果数组
     * @date 2021/4/22 20:46
     */
    public AbstractHit[] search(AbstractTerm queryTerm1, AbstractTerm queryTerm2, Sort sorter) {
        this.queryTerm1 = queryTerm1;
        this.queryTerm2 = queryTerm2;
        this.sorter = sorter;
        AbstractPostingList postList1 = index.search(queryTerm1);
        AbstractPostingList postList2 = index.search(queryTerm2);
        if (postList1 == null || postList2 == null)//有一个为空时就返回null
            return null;
        List<AbstractHit> hits = new ArrayList<>();
        int i = 0, j = 0;
        while (i < postList1.size() && j < postList2.size()) {
            AbstractPosting post1 = postList1.get(i);
            AbstractPosting post2 = postList2.get(j);
            if (post1.getDocId() == post2.getDocId()) {//若所在文档一样
                List<Integer> position1 = post1.getPositions();
                List<Integer> position2 = post2.getPositions();
                int i1 = 0, i2 = 0;
                List<Integer> positions = new ArrayList<>();
                while (i1 < position1.size() && i2 < position2.size()) {
                    int p1 = position1.get(i1);
                    int p2 = position2.get(i2);
                    if (p1 == p2 - 1) {//当相邻时候添加
                        positions.add(p1);
                        i1++;
                        i2++;
                    } else if (p1 < p2 - 1) {
                        i1++;
                    } else {
                        i2++;
                    }
                }
                if (positions.size() > 0) {
                    String path = index.getDocName(post1.getDocId());
                    Map<AbstractTerm, AbstractPosting> map = new HashMap<>();
                    map.put(new Term(queryTerm1.getContent() + " " + queryTerm2.getContent()),
                            new Posting(post1.getDocId(), positions.size(), positions));
                    AbstractHit hit = new Hit(post1.getDocId(), path, map);
                    hit.setScore(sorter.score(hit));        // 先设置分数
                    hits.add(hit);
                }
                i++;
                j++;
            } else if (post1.getDocId() < post2.getDocId()) {
                i++;
            } else {
                j++;
            }
        }
        if (hits.size() < 1) return null;
        new SimpleSorter().sort(hits);
        return hits.toArray(new Hit[0]);
    }
}


