package hust.cs.javacourse.search.parse.impl;

import hust.cs.javacourse.search.index.AbstractTermTuple;
import hust.cs.javacourse.search.parse.AbstractTermTupleFilter;
import hust.cs.javacourse.search.parse.AbstractTermTupleStream;
import hust.cs.javacourse.search.util.StopWords;

import java.util.Arrays;

/**
 * 停用词过滤器
 * @author ShiShenao
 * @date 2021/4/16
 **/

public class StopWordTermTupleFilter extends AbstractTermTupleFilter {

    /**
     * StopWordTermTupleFilter的构造函数
     * @param input:Filter的输入，类型为AbstractTermTupleStream
     * @date 2021/4/16 20:20
     */
    public StopWordTermTupleFilter(AbstractTermTupleStream input){
        super(input);
    }

    /**
     * 获得下一个三元组
     * @return 下一个三元组；如果到了流的末尾，返回null
     * @date 2021/4/17 16:39
     */
    @Override
    public AbstractTermTuple next() {
        AbstractTermTuple termTuple = input.next();
        if (termTuple == null) {
            return null;
        }
        while (Arrays.asList(StopWords.STOP_WORDS).contains(termTuple.term.getContent())) {//如果含有停用词,取下一个三元组
            termTuple = input.next();
            if (termTuple == null) {
                return null;
            }
        }
        return termTuple;
    }
}
