package homework.ch11_13.p1;

public class Task3 implements Task{
    /**
     * 执行具体任务的接口方法
     */
    public void execute(){
        System.out.println("Task3");
    }
}
