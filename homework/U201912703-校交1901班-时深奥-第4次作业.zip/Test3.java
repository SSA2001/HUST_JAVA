package ch1;
//import java.util.Scanner;

public class Test3 {
    public static void main(String[] args){
     //   Scanner scanner = new Scanner(System.in);
        int row = Integer.parseInt(args[0]);
        int[][]array = createArray(row);
        printArray(array);
    }
    public static int[][] createArray(int row){
        if(row<=0) {
            System.out.println("您输入的行数不合法!");
            int[][] array = {};
            return array;
        }
        int[][]array = new int[row][];
        for(int i = 0; i < row; i++)
            array[i] = new int[row-i];
        return array;
    }
    public static void printArray(int[][]array){
        for(int i = 0; i < array.length; i++) {
            for(int j = 0; j < array[i].length; j++) {
                System.out.print(array[i][j]);
                System.out.print(" ");
            }
            System.out.println("\n");
        }
    }
}
