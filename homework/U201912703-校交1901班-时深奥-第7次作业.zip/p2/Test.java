package p2;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

class TwoTuple<T1 extends Comparable,T2 extends Comparable> implements Comparable {
    private T1 first;
    private T2 second;

    public void setFirst(T1 first) {
        this.first = first;
    }

    public void setSecond(T2 second) {
        this.second = second;
    }

    public T1 getFirst() {
        return first;
    }

    public T2 getSecond() {
        return second;
    }

    public TwoTuple(T1 a, T2 b) {
        first = a;
        second = b;
    }

    @Override
    public String toString() {
        return "(" + first + ", " + second + ")";
    }

    @Override
    public boolean equals(Object o) {
        if (o instanceof TwoTuple) {
            if(this.getFirst().equals(((TwoTuple<?, ?>) o).getFirst()) && this.getSecond().equals(((TwoTuple) o).getSecond())){
                return true;
            }
        }
        return false;
    }

    @Override
    public int compareTo(Object o) {
        TwoTuple temp = (TwoTuple) o;
        if(this.getFirst().equals(temp.getFirst()))
        {
            if(this.getSecond() instanceof TwoTuple)
                return ((TwoTuple)this.getSecond()).compareTo((TwoTuple)temp.getSecond());
            return this.getSecond().compareTo(temp.getSecond());
        }
        if(this.getFirst() instanceof TwoTuple)
            return ((TwoTuple)this.getFirst()).compareTo((TwoTuple)temp.getFirst());
        return this.getFirst().compareTo(temp.getFirst());
    }
}

public class Test {
    public static void main(String[] args) {
        TwoTuple<Integer, String> twoTuple1 = new TwoTuple<>(1, "ccc");
        TwoTuple<Integer, String> twoTuple2 = new TwoTuple<>(1, "bbb");
        TwoTuple<Integer, String> twoTuple3 = new TwoTuple<>(1, "aaa");
        TwoTuple<Integer, String> twoTuple4 = new TwoTuple<>(2, "ccc");
        TwoTuple<Integer, String> twoTuple5 = new TwoTuple<>(2, "bbb");
        TwoTuple<Integer, String> twoTuple6 = new TwoTuple<>(2, "aaa");
        List<TwoTuple<Integer, String>> list = new ArrayList<>();
        list.add(twoTuple1);
        list.add(twoTuple2);
        list.add(twoTuple3);
        list.add(twoTuple4);
        list.add(twoTuple5);
        list.add(twoTuple6);

        //测试equals，contains方法是基于equals方法结果来判断
        TwoTuple<Integer, String> twoTuple10 = new TwoTuple<>(1, "ccc"); //内容=twoTuple1
        System.out.println(twoTuple1.equals(twoTuple10)); //应该为true
        if (!list.contains(twoTuple10)) {
            list.add(twoTuple10);  //这时不应该重复加入
        }

        //sort方法是根据元素的compareTo方法结果进行排序，课测试compareTo方法是否实现正确
        Collections.sort(list);


        for (TwoTuple<Integer, String> t : list) {
            System.out.println(t);
        }

        TwoTuple<TwoTuple<Integer, String>, TwoTuple<Integer, String>> tt1 =
                new TwoTuple<>(new TwoTuple<>(1, "aaa"), new TwoTuple<>(1, "bbb"));
        TwoTuple<TwoTuple<Integer, String>, TwoTuple<Integer, String>> tt2 =
                new TwoTuple<>(new TwoTuple<>(1, "aaa"), new TwoTuple<>(2, "bbb"));
        System.out.println(tt1.compareTo(tt2)); //输出-1
        System.out.println(tt1);
    }
}

