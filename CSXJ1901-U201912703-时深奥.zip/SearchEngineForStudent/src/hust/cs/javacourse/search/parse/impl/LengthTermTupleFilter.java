package hust.cs.javacourse.search.parse.impl;

import hust.cs.javacourse.search.index.AbstractTermTuple;
import hust.cs.javacourse.search.parse.AbstractTermTupleFilter;
import hust.cs.javacourse.search.parse.AbstractTermTupleStream;
import hust.cs.javacourse.search.util.Config;

/**
 * 基于单词长度的过滤器
 * @author ShiShenao
 * @date 2021/4/16
 **/
public class LengthTermTupleFilter extends AbstractTermTupleFilter {

    /**
     * LengthTermTupleFilter的构造函数
     * @param input:Filter的输入，类型为AbstractTermTupleStream
     * @date 2021/4/16 20:30
     */
    public LengthTermTupleFilter(AbstractTermTupleStream input){
        super(input);
    }

    /**
     * 获得下一个三元组
     * @return 下一个三元组；如果到了流的末尾，返回null
     * @date 2021/4/17 15:35
     */
    @Override
    public AbstractTermTuple next() {
        AbstractTermTuple termTuple = input.next();
        if (termTuple == null)
            return null;
        while (termTuple.term.getContent().length() > Config.TERM_FILTER_MAXLENGTH ||
                termTuple.term.getContent().length() < Config.TERM_FILTER_MINLENGTH ) {//筛选长度
            termTuple = input.next();//取下一个三元组
            if (termTuple == null)
                return null;
        }
        return termTuple;
    }
}
